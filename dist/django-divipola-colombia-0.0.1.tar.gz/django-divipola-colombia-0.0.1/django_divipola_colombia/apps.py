from django.apps import AppConfig


class DjangoDivipolaColombiaConfig(AppConfig):
    name = 'django_divipola_colombia'
