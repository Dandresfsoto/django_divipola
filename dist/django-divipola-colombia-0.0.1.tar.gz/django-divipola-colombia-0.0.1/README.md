##django-divipola-colombia

django-divipola-colombia es una app simple para implementar en Django la división político administrativa de colombia Divipola

La documentación detallada se encuentra en el directorio "docs".